/*=================================================
 Authors:	cristianmandelli@gmail.com 
	      	deborahzamponi@gmail.com
 Data: 17/01/2012
 Description: Brian
=================================================*/

#include <stdio.h>
#include <string.h>

//Ros Libraries
#include <brian.h>
#include <getFuzzy.h>
#include "ros/ros.h"
#include "ros/package.h"
#include "StateMachine.h"

//Ros Messages
#include "user_tracker/Com.h"
#include "head_analyzer/MoveDataMSG.h"
#include "head_analyzer/HeadDataMSG.h"
#include "head_analyzer/EyesDataMSG.h"
#include "robot_brain/WheelData.h"
#include "robot_brain/HighLevelData.h"
#include "std_msgs/String.h"

#define MAX_WHEEL_SPEED_GAP 5

using namespace std;

enum transaction { AGREE, DISAGREE, INTERESTED, NOT_CLOSED };
enum nodeID { APPROACH, REGARDS, REQUEST_ATTENTION, START_INTERACTION, EXPLANATION, UPSET_REQ_ATTENTION, INVITATION };

//Variables
//==============================================================================
//==============================================================================
int userDistance;
int userXPosition;
int OUTtanSpeed;
int OUTrotSpeed;

float userEyeLRatio;
float userEyeRRatio;
float userHeadRatio;

string userMoveClass;

StateMachine* sm;

//Control Variables
bool userPositionDataReady;
bool userEyesDataReady;
bool userMoveDataReady;
bool userHeadDataReady;

//Messages published
robot_brain::WheelData wheelDataMSG;
robot_brain::HighLevelData hldMSG;

//Protoypes
//==============================================================================
//==============================================================================
//Get data from modules
void getUserPositionData(const user_tracker::Com com);
void getUserEyesData(const head_analyzer::EyesDataMSG eyes);
void getUserHeadData(const head_analyzer::HeadDataMSG head);
void getUserMoveData(const head_analyzer::MoveDataMSG move);
void stateMachineInit();

//Compile messages
void compileMessages();

//Other functions

/*This function estimates user attention value into [0; 10] range
 *using data from head analyzer such as MoveClass and userHeadRatio
 *If estimation cannot be done, the function return 0, otherwise the returned
 *value is the current user attention* */
unsigned int userAttentionEstimation();

//Functions
//==============================================================================
//==============================================================================
int main(int argc, char **argv)
{
    //Initialization
    userDistance = -1;
    userEyeLRatio = -1.0;
    userEyeRRatio = -1.0;
    userHeadRatio = -1.0;
    userMoveClass = "U";
    OUTrotSpeed = 0;
    OUTtanSpeed = 0;
    
    //State Machine initialization
    stateMachineInit();
    
    
    //Control Variable
    bool brianActivated = false;
    bool WheelSpeedMessages = false;
    bool hldMessages = false;
    userPositionDataReady = false;
    userEyesDataReady = false;
    userMoveDataReady = false;
	userHeadDataReady = false;
    
    ros::init(argc, argv, "robot_brain");
    ros::NodeHandle nh;
    
    //Liste per lo "scambio" dati con brian
		crisp_data_list* cdl;    //lista in ingresso
		command_list * cl;       //lista in uscita
    
    //Messages subscribers
    ros::Subscriber subUserDistance = nh.subscribe("com", 100, getUserPositionData);
    ros::Subscriber subUserHeadData = nh.subscribe("headData", 10, getUserHeadData);	
    ros::Subscriber subUserEyesData = nh.subscribe("eyesData", 10, getUserEyesData);	
    ros::Subscriber subUserMoveData = nh.subscribe("moveData", 10, getUserMoveData);	
    
    //Messages Published
	ros::Publisher pubWheelData = nh.advertise<robot_brain::WheelData>("wheel_data", 100);
	ros::Publisher pubHldData = nh.advertise<robot_brain::HighLevelData>("hl_data", 100);

   
    ROS_INFO("---------------> Starting Brian...");
    string ctofFilename = ros::package::getPath("robot_brain")+"/config/brian_config/ctof.txt";
    string shape_ctofFilename = ros::package::getPath("robot_brain")+"/config/brian_config/shape_ctof.txt";
    string PredicateFilename = ros::package::getPath("robot_brain")+"/config/brian_config/predicate.ini";
    string PredicateActionsFilename = ros::package::getPath("robot_brain")+"/config/brian_config/predicateActions.ini";
    string CandoFilename = ros::package::getPath("robot_brain")+"/config/brian_config/cando.ini";
    string behaviourFilename = ros::package::getPath("robot_brain")+"/config/brian_config/behaviour.txt";
    string wantFilename = ros::package::getPath("robot_brain")+"/config/brian_config/want.txt";
    string s_ftocFilename = ros::package::getPath("robot_brain")+"/config/brian_config/s_ftoc.txt";
    string s_shapeFilename = ros::package::getPath("robot_brain")+"/config/brian_config/s_shape.txt";

    MrBrian *brian = new MrBrian((char*)ctofFilename.c_str(), 
                                 (char*)shape_ctofFilename.c_str(),
                                 (char*)PredicateFilename.c_str(), 
                                 (char*)PredicateActionsFilename.c_str(),
                                 (char*)CandoFilename.c_str(),
                                 (char*)behaviourFilename.c_str(), 
                                 (char*)wantFilename.c_str(), 
                                 (char*)s_ftocFilename.c_str(), 
                                 (char*)s_shapeFilename.c_str());
	ROS_INFO("!! MrBrian !! ");
			
	ros::Rate r(30);
	while(ros::ok())	//ROS LOOP
    {
        //Get Input data list
        cdl = (brian->getFuzzy())->get_crisp_data_list();
        //Clear input data list
        cdl->clear();
        
        //==========================================================================
        //						Reading message from INPUT
        //==========================================================================
        //With ROS this step is automatic with messages callbacks
        
        //==========================================================================
        //						Updating INPUT data
        //==========================================================================
				//Read User_Tracker data
				if(userPositionDataReady)
				{
					cdl->add(new crisp_data("UserDetected", true, 1));
					cdl->add(new crisp_data("UserDistance", userDistance, 1));
					cdl->add(new crisp_data("UserXPosition", userXPosition, 1));
				}
				else
				{
					cdl->add(new crisp_data("UserDetected", false, 1));
				}
							
				//Read Head_Analyzer data
				//Read Motor Data
        //==========================================================================
        //						Brian algorithm
        //==========================================================================
        if (brianActivated)
        {
						//ROS_INFO("Brian running...");
            //brian->run();
            //brian->debug();
        }
        
        //==========================================================================
        //                      Updating OUTPUT data
        //==========================================================================
        //Read output data
        cl = (brian->getFuzzy())->get_command_singleton_list();
        if (cl!=0) 
        {
					//ROS_INFO("Brain saids...");
          command_list::iterator it;

          for (it = cl->begin(); it != cl->end(); it++) 
          {
						string temp = it->first;

						if (temp.compare("TanSpeed") == 0) 
						{
							//ROS_ERROR("TanSpeed: %d", (int) it->second->get_set_point());
							int temp = (int)it->second->get_set_point();
							/*if(temp >= OUTtanSpeed - MAX_WHEEL_SPEED_GAP && temp <= OUTtanSpeed + MAX_WHEEL_SPEED_GAP)
							{ 
									OUTtanSpeed = OUTtanSpeed;
									temp = OUTtanSpeed;
									WheelSpeedMessages = false;
							}
							else*/
									OUTtanSpeed = temp;
									WheelSpeedMessages = true;
						}
						
						if (temp.compare("RotSpeed") == 0) 
						{
							//ROS_ERROR("TanSpeed: %d", (int) it->second->get_set_point());
							OUTrotSpeed = (int)it->second->get_set_point();
						}
					}
        }
                
        //Clear output data
        cl->clear();
        
        //==========================================================================
        //						Compiling message to Motor and other modules
        //==========================================================================
        compileMessages();
        //if(WheelSpeedMessages) 
				pubWheelData.publish(wheelDataMSG);	             
        
        ros::spinOnce();
				r.sleep();
    }    
}

//==============================================================================
//==============================================================================
void compileMessages()
{
	//Publish Wheel Data
	wheelDataMSG.tanSpeed.data = OUTtanSpeed;
	wheelDataMSG.rotSpeed.data = OUTrotSpeed;
	
	//TO_DO: Publish High Level Data
	
	
	//ROS_INFO("TanSpeed: %d   RotSpeed: %d", OUTtanSpeed, OUTrotSpeed);
}


//==============================================================================
//==============================================================================
void stateMachineInit()
{
	Node node = Node(APPROACH, "Approach", "001001", "a");
	sm = new StateMachine(node);
	
	node = Node(REGARDS, "Regards", "110101", "a");
	sm->addNode(node);
	
	node = Node(REQUEST_ATTENTION, "RequestAttention", "010101", "a");
	sm->addNode(node);
	
	node = Node(START_INTERACTION, "StartInteraction", "110011", "a");
	sm->addNode(node);
	
	node = Node(EXPLANATION, "Explanation", "111000", "a");
	sm->addNode(node);
	
	node = Node(UPSET_REQ_ATTENTION, "UpsetRequestAttention", "000111", "a");
	sm->addNode(node);
	
	node = Node(INVITATION, "Invitation", "111111", "a");
	sm->addNode(node);
	
	sm->setTransictionBt(APPROACH,START_INTERACTION, AGREE);
	sm->setTransictionBt(APPROACH,START_INTERACTION, INTERESTED);
	sm->setTransictionBt(APPROACH,REQUEST_ATTENTION, NOT_CLOSED);
	sm->setTransictionBt(APPROACH,REGARDS, DISAGREE);
	sm->setTransictionBt(START_INTERACTION,EXPLANATION, AGREE);
	sm->setTransictionBt(START_INTERACTION,EXPLANATION, INTERESTED);
	sm->setTransictionBt(START_INTERACTION,UPSET_REQ_ATTENTION, NOT_CLOSED);
	sm->setTransictionBt(START_INTERACTION,REGARDS, DISAGREE);
	sm->setTransictionBt(EXPLANATION,INVITATION, AGREE);
	sm->setTransictionBt(EXPLANATION,INVITATION, INTERESTED);
	sm->setTransictionBt(EXPLANATION,UPSET_REQ_ATTENTION, NOT_CLOSED);
	sm->setTransictionBt(UPSET_REQ_ATTENTION,EXPLANATION, INTERESTED);
	sm->setTransictionBt(UPSET_REQ_ATTENTION,REGARDS, DISAGREE);
	sm->setTransictionBt(UPSET_REQ_ATTENTION,REGARDS, NOT_CLOSED);
	sm->setTransictionBt(REQUEST_ATTENTION,START_INTERACTION, INTERESTED);
	sm->setTransictionBt(REQUEST_ATTENTION,START_INTERACTION, AGREE);
	sm->setTransictionBt(REQUEST_ATTENTION,REGARDS, DISAGREE);
	sm->setTransictionBt(REQUEST_ATTENTION,REGARDS, NOT_CLOSED);
	
	sm->printMap();
}


//==============================================================================
//==============================================================================
unsigned int userAttentionEstimation()
{
	unsigned int attention = 0;
	
	
	
	
	return attention;
}

//==============================================================================
//==============================================================================
void getUserPositionData(const user_tracker::Com com)
{
	
    //Save user's distance from camera (z coord)
    userDistance = (int)com.comPoints.z;
    userXPosition = (int)com.comPoints.x;
    
    //Check if there are still a user
    if (userDistance > 0)
        userPositionDataReady = true;
    else
    {
        ROS_INFO("User out of camera");
        userPositionDataReady = false;
    }
    
    //ROS_INFO("PosizioneXUtente: %d", userXPosition);
}


//==============================================================================
//==============================================================================
void getUserEyesData (const head_analyzer::EyesDataMSG eyesData)
{
	userEyeLRatio = (float)eyesData.eyeLRatio.data;
	userEyeRRatio = (float)eyesData.eyeRRatio.data;
	
	if(userEyeLRatio > 0.0 || userEyeRRatio > 0.0)
		userEyesDataReady = true;
	else
		userEyesDataReady = false;
		
	ROS_INFO("Eyes Ratio: R=%f L=%f", userEyeRRatio, userEyeLRatio);
}


//==============================================================================
//==============================================================================
void getUserMoveData (const head_analyzer::MoveDataMSG moveData)
{
	userMoveClass = (moveData.moveClassification.data);
	userMoveDataReady = true;
	
	ROS_INFO("Move  %s", userMoveClass.c_str());
}

//==============================================================================
//==============================================================================
void getUserHeadData(const head_analyzer::HeadDataMSG headData)
{
	userHeadRatio = (float)headData.headRatio.data;
	if( userHeadRatio > 0.0)
		userHeadDataReady = true;
	else
		userHeadDataReady = false;
		
	ROS_INFO("Head Ratio %f", userHeadRatio);
}
